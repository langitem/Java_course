// Emanuel Langit
// emanuel.langit@my.ohecampus.com
// CKIT-510
// DQ1_test.java
// Application to test DQ1 class
// Week 1 DQ1
// July 17, 2013

public class DQ1_test {
	
	public static void main(String[] args) {
		
		// create DQ1 object and assign it to myDQ1
		DQ1 myDQ1 = new DQ1();
		
		myDQ1.displayWelcomeMessage();
		myDQ1.askForName();
		myDQ1.askForBirthday();
		myDQ1.displayNameAndBirthday();
	} // end of main method

} // end of DQ1_test class
