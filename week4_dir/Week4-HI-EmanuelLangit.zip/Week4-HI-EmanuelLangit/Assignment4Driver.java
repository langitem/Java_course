// Emanuel Langit
// emanuel.langit@my.ohecampus.com
// CKIT-510
// Assignment4Driver.java
// Driver class for Week 4 Assignment
// Week 4 Assignment
// July 31, 2013

import javax.swing.JFrame;

public class Assignment4Driver {
	
	public static void main(String[] args) {
		Assignment4JFrame myJFrame = new Assignment4JFrame();
		myJFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		myJFrame.setLocationRelativeTo(null);
		myJFrame.setSize(450, 150);
		myJFrame.setVisible(true);
	}

}
