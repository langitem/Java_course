// Emanuel Langit
// emanuel.langit@my.ohecampus.com
// CKIT-510
// Week4DQ2Driver.java
// Driver class class for DQ2
// Week 4 DQ2
// July 29, 2013

import javax.swing.JFrame;

public class Week4DQ2Driver {
	
	public static void main(String[] args) {
		
		Week4DQ2Frame myFrame = new Week4DQ2Frame();
		myFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		myFrame.setLocationRelativeTo(null);
		myFrame.setSize(275, 110);
		myFrame.setVisible(true);
	}

}
