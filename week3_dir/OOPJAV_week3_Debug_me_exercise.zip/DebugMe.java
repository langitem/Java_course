public class DebugReview

	public static void rev(String args){
		double r = 14;
		DebugMe rev = new Debug Me();
		rev.one(r);
	}

	public void double one(int myVar){
		System.out.prntln("my Var is + my Var);
		int x = two(myvar)
		System.out.println("x is " + x);
	}

	public integer two(float myInt){
		int k = myInt + 2;
		return k
	}
}

//Output should read:
//myVar is 14
//x is 28
//on two separate lines as shown
//in your message window.


