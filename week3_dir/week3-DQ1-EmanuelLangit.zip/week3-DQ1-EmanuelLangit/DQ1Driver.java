// Emanuel Langit
// emanuel.langit@my.ohecampus.com
// CKIT-510
// DQ1Driver.java
// Driver class for DQ1
// Week 3 DQ1
// July 21, 2013

public class DQ1Driver {
	
	public static void main(String[] args) {
		
		DQ1Application myDQ1App = new DQ1Application();
		
		myDQ1App.displayGreeting();
		myDQ1App.getDoubles();
		myDQ1App.displayResult();
		
		System.exit(0);
	}

}
