// Emanuel Langit
// emanuel.langit@my.ohecampus.com
// CKIT-510
// DQ2Application.java
// Application class for DQ2
// Week 3 DQ2
// July 21, 2013

public class DQ2Driver {
	
	public static void main(String[] args) {
		
		DQ2Application myDQ2App = new DQ2Application();
		
		myDQ2App.displayGreeting();
		myDQ2App.getMonthNum();
		myDQ2App.displayMonth();
		
		System.exit(0);
	}

}
