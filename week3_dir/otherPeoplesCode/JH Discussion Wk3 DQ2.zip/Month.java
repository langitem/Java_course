import javax.swing.*;

public class Month{

       public static void main(String[ ] args){
	      GetUserData myUserData = new GetUserData();
              myUserData.GetMonth();
}
}