import javax.swing.*;

public class GetUserData{

	      int month;

       public void GetMonth(){
               String monthEntry = JOptionPane.showInputDialog("Please enter the month number to convert");  
        if(monthEntry.length() > 0) {
        month = Integer.parseInt(monthEntry);
        }
        else{
        month = 0;
        }
	      switch (month){
	      case 1:
	      JOptionPane.showMessageDialog(null, "You entered 1 which means January");
	      break;
	      case 2:
	      JOptionPane.showMessageDialog(null, "You entered 2 which means February");
	      break;
	      case 3:
	      JOptionPane.showMessageDialog(null, "You entered 3 which means March");
	      break;
	      case 4:
	      JOptionPane.showMessageDialog(null, "You entered 4 which means April");
	      break;
	      case 5:
	      JOptionPane.showMessageDialog(null, "You entered 5 which means May");
	      break;
	      case 6:
	      JOptionPane.showMessageDialog(null, "You entered 6 which means June");
	      break;
	      case 7:
	      JOptionPane.showMessageDialog(null, "You entered 7 which means July");
	      break;
	      case 8:
	      JOptionPane.showMessageDialog(null, "You entered 8 which means August");
	      break;
	      case 9:
	      JOptionPane.showMessageDialog(null, "You entered 9 which means September");
	      break;
	      case 10:
	      JOptionPane.showMessageDialog(null, "You entered 10 which means October");
	      break;
	      case 11:
	      JOptionPane.showMessageDialog(null, "You entered 11 which means November");
	      break;
	      case 12:
	      JOptionPane.showMessageDialog(null, "You entered 12 which means December");
	      break;
	      default:
	      JOptionPane.showMessageDialog(null, "You entered a number that was either more than 12 or less than 1.");

}


}}