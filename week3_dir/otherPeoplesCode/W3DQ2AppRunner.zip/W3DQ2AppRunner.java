import javax.swing.*; 
  
//Call a main method which will call App method instance 
  
public class W3DQ2AppRunner 
{ 
    public static void main(String[] args) 
	 { 
        	
		  MonthName appMonthName = new MonthName(); 
			 appMonthName.monthNumber(); 
         
	 } 
} 
