//UoL CKIT510 
//Delisa SImonovic 
//July 2013 
//W3 - DQ2
import javax.swing.*; 
import java.text.*;
  
//Create a class that will contain needed methods and dialog objects  
  
public class MonthName 
{
	//Declare variables
	public static String monthNum;
	public static String month;
	public static String monthPosition;
	
	//Method for input validation 			
	public static boolean isNumeric(String str)
	{
		 NumberFormat formatter = NumberFormat.getInstance();
		 ParsePosition pos = new ParsePosition(0);
		 formatter.parse(str, pos);
		 return str.length() == pos.getIndex();
	}
	
	public void monthNumber()  
	{    
		    
	 
	
		//Prompt user for input		
		MonthName.monthNum=JOptionPane.showInputDialog(null,
												    "Please enter month number:", 
												    "Which month?",
												    JOptionPane.QUESTION_MESSAGE);
		
	 
		
	 	try	  	
	      {
			   //Validation if input is numeric
				if (isNumeric(monthNum))
					{	
						//Switch case statements are used to output corresponding month name
				   	switch (Integer.parseInt(monthNum)) {
	            	case 1:  month = "January.";
									monthPosition = "First month is";
	                        break;
	            	case 2:  month = "February.";
									monthPosition = "Second month is";
	                        break;
		            case 3:  month = "March.";
									monthPosition = "Third month is";
		                     break;
		            case 4:  month = "April.";
									monthPosition = "Fourth month is";
		                     break;
		            case 5:  month = "May.";
									monthPosition = "Fifth month is";
		                     break;
		            case 6:  month = "June.";
									monthPosition = "Sixth month is";
		                     break;
		            case 7:  month = "July.";
									monthPosition = "Seventh month is";
		                     break;
		            case 8:  month = "August.";
									monthPosition = "Eighth month is";
		                     break;
		            case 9:  month = "September.";
									monthPosition = "Ninth month is";
		                     break;
		            case 10: month = "October.";
									monthPosition = "Tenth month is";
		                     break;
		            case 11: month = "November.";
									monthPosition = "Eleventh month is";
		                     break;
		            case 12: month = "December.";
									monthPosition = "Twelfth";
		                     break;
		            default: month = "There are only twelve months!";
									monthPosition = "Invalid month.";
		                     break;
	            													} 
						if (monthPosition == "Invalid month.")
	           	     		{
									JOptionPane.showMessageDialog(null,
	    														monthPosition+ " " +month);
										
									monthNumber();						   
								}	
				
						else 
								{
									JOptionPane.showMessageDialog(null,
	    														monthPosition+ " " +month);
							   }
			   }
				else
			   {
					JOptionPane.showConfirmDialog(null, "Please enter numerical value!",
														"Warning!",
														JOptionPane.WARNING_MESSAGE);
					//If input is not numeric then call monthNumber method again										
					monthNumber();
			   }
	     }
		  //Empty string validation if nothing is entered
		  catch(NumberFormatException e )
		  {
				JOptionPane.showMessageDialog(null, 			
				                     			" You entered no value!", 
				                      			"Result", 
				                      			JOptionPane.INFORMATION_MESSAGE);
		   
				monthNumber();
		  }
	
   }
}