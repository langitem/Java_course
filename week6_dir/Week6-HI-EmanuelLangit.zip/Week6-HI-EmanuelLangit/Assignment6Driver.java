// Emanuel Langit
// emanuel.langit@my.ohecampus.com
// CKIT-510
// Assignment6Driver.java
// Driver class for assignment 6
// Week 6 Assignment
// August 14, 2013

import javax.swing.JFrame;


public class Assignment6Driver {
	
	public static void main(String[] args) {
		Assignment6App myApp = new Assignment6App();
		myApp.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		myApp.setLocationRelativeTo(null);
		myApp.setSize(650, 300);
		myApp.setVisible(true);
	}

}
