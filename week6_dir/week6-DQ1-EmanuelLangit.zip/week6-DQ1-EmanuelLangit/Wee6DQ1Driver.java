// Emanuel Langit
// emanuel.langit@my.ohecampus.com
// CKIT-510
// Week6DQ1Driver.java
// Driver class for Week 6 DQ1
// Week 6 DQ1
// August 11, 2013

import javax.swing.JFrame;

public class Wee6DQ1Driver {

	public static void main(String[] args) {
		
		Week6DQ1App myApp = new Week6DQ1App();
		myApp.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		myApp.setLocationRelativeTo(null);
		myApp.setSize(275, 100);
		myApp.setVisible(true);

	}

}
