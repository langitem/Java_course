// Emanuel Langit
// emanuel.langit@my.ohecampus.com
// CKIT-510
// DQ2Driver.java
// Driver class for DQ2
// DQ2
// July 14, 2013

public class DQ2Driver {
	
	public static void main(String[] args) {
		DQ2Application myDQ2Application = new DQ2Application();
		
		myDQ2Application.displayGreeting();
		myDQ2Application.getInput();
		myDQ2Application.displaySpeed();
		System.exit(0);
	}

}
