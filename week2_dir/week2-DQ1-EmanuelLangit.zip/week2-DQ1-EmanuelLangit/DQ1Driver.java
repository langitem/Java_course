// Emanuel Langit
// emanuel.langit@my.ohecampus.com
// CKIT-510
// DQ1Driver.java
// Driver class for DQ1
// DQ1
// July 14, 2013

public class DQ1Driver {
	
	public static void main(String[] args) {
		
		DQ1Application myDQ1Application = new DQ1Application();
		
		myDQ1Application.displayGreeting();
		myDQ1Application.getDistanceInMeters();
		myDQ1Application.displayDistanceInKm();
		System.exit(0);
	}

}
