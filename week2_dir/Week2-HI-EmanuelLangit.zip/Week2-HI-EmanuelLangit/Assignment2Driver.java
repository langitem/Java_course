// Emanuel Langit
// emanuel.langit@my.ohecampus.com
// CKIT-510
// Assignment2Driver.java
// Driver class
// Week 2 Hand-in assignment
// July 17, 2013

public class Assignment2Driver {
	
	public static void main(String[] args) {
		
		Assignment2App myApp = new Assignment2App(); // create instance of Assignment2App
		
		myApp.greeting();
		myApp.getPoolDimensions();
		myApp.displayVolume();
		myApp.displayFillTime();
		
		System.exit(0);
	}

}