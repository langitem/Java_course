// Run Inheritance Class
// Dr. Y. Jing
// 06 December 2007
// The university of Liverpool, UK

import java.io.*;

class RunInheritance{

// Main method

public static void main (String[] args){
SchoolEmployee se = new SchoolEmployee("Peter Johnson", 24000);
Teacher t = new Teacher ("Jack heart", 26000, "Science");
se.printSchoolEmployeeDetails();
t.printTeacherDetails();
}
}

