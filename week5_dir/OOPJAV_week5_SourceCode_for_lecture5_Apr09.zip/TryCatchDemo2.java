// Exception Handling Class
// Dr. Y. Jing
// 06 December 2007
// The university of Liverpool, UK

import java.io.*;

class TryCatchDemo2{
// --- Fields ---

static BufferedReader keyboard = new BufferedReader(new InputStreamReader(System.in));

// Main method
// Since the IO exception isn't handled in my code, I am throwing the exeption to the system

public static void main(String[] args) throws IOException{
	int firstInt, secondInt, check;
	float result;
	boolean tryAgain;
		do {
			tryAgain=false;
			firstInt=0;
			secondInt=0;
			System.out.println("Program to divid 1st integer by 2nd Integer");
			try {
				System.out.println("\n Please Enter 1st Integer:");
				firstInt = new Integer(keyboard.readLine()).intValue();
				System.out.println("\n Please Enter 2nd Integer:");
				secondInt = new Integer(keyboard.readLine()).intValue();
				result = (float)(firstInt/secondInt);
				System.out.println("Result="+result);
				}
			catch(NumberFormatException nfe){
				System.out.println("\n You didn't enter an integer, Please try again");
				tryAgain=true;
				}
			catch(ArithmeticException ae){
				System.out.println("Division by zero has occurred. Please try again.");
				tryAgain=true;
				}
		}while (tryAgain);
	}
}