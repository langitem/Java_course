// School Employee Class
// Dr. Y. Jing
// 06 December 2007
// The university of Liverpool, UK

import java.io.*;

class SchoolEmployee{
// --- Fields ---

protected String name;
protected int salary;

// --- Constructors ---

public SchoolEmployee(String n, int s){
	name = n;
	salary = s;
	}
// --- Methods ---

public void printSchoolEmployeeDetails(){
	System.out.println("SchoolEmployee:");
	System.out.println("Name ="+name);
	System.out.println("Salary ="+salary);
	System.out.println("");
	}
}