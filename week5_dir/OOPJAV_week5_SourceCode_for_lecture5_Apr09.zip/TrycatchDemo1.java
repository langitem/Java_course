// Hnadle Exception Class
// Dr. Y. Jing
// 06 December 2007
// The university of Liverpool, UK
import java.io.*;
class TrycatchDemo1{
// --- Fields ---
static BufferedReader keyboard = new BufferedReader(new InputStreamReader(System.in));
// Main method since he IO exception isn't handled in my code,
// I'm throwing this exception to the system
public static void main (String[] args) throws IOException{
	int firstInt, secondInt, check;
	float result;
	boolean tryAgain1, tryAgain2;
	do {
		tryAgain2=false;
		firstInt=0;
		secondInt=0;
		System.out.println("Program to divid 1st integer by 2nd Integer");
		do {
			tryAgain1=false;
			try {
				System.out.println("\n Please Enter 1st Integer:");
				firstInt = new Integer(keyboard.readLine()).intValue();
				System.out.println("\n Please Enter 2nd Integer:");
				secondInt = new Integer(keyboard.readLine()).intValue();
				}
			catch(NumberFormatException nfe){
				System.out.println("\n You didn't enter an integer, Please try again");
				tryAgain1=true;
				}
			}while (tryAgain1);
			try {
				result = (float)(firstInt/secondInt);
				System.out.println("Result="+result);
			}
			catch(ArithmeticException ae){
				System.out.println("Division by zero has occurred. Please try again.");
				tryAgain2=true;
				}
		}while (tryAgain2);
}
}

