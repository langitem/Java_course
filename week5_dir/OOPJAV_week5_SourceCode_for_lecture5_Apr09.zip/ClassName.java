// Encapsulated Class
// Dr. Y. Jing
// 06 December 2007
// The university of Liverpool, UK

class ClassName{
// --- Fields ---

private String attribute1;
private int attribute2;

// --- Constructors ---

public ClassName(String a1, int a2){
attribute1=a1;
attribute2=a2;
}

public ClassName(){
attribute1="";
attribute2=0;
}

// --- Public Instance Methods

public String getAttribute1(){return attribute1;}
public int getAttribute2(){return attribute2;}
public void setAttribute1(String newA1){attribute1=newA1;}
public void setAttribute1(int newA2){attribute2=newA2;}

// --- Private Class Methods ---

private static void someMethod(){
	/*
	Code for some internal processsing can be placed
	here. This method can be called only from bjects
	instantiated from this class. It is not available
	to other classes.
	*/
	}
}