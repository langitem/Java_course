//Teacher Class
// Dr. Y. Jing
// 06 December 2007
// The university of Liverpool, UK

import java.io.*;

class Teacher extends SchoolEmployee{
// --- Fields ---
private String subject;

// --- Constructor ---

public Teacher (String n, int s, String sub){
	super(n,s);
	subject = sub;
}

// --- Methods ---

public void printTeacherDetails(){
	System.out.println("Teacher:");
	System.out.println("Name=" +name);
	System.out.println("Salary="+salary);
	System.out.println("Subject="+subject);
}
}