// Partial Exception Handling Class
// This code is not a full program in itself but may be used
// to illustrate how exceptions may be handled within a program
// Dr. Y. Jing
// 06 December 2007
// The university of Liverpool, UK

int myInteger;
int check;
do {
	check =0;
	try {
		System.out,println("\n Please Enter an Integer");
		myInteger=new Interger(keyboardInput.readLine()).intValue;
		System.out.println("Value of myInteger="+myInteger);
	}
	catch (NumberFormatException nfe){
	System.out.println("\n You did not enter an Integer. Please try again.");
	check = 1;
	}
}while (check == 1);