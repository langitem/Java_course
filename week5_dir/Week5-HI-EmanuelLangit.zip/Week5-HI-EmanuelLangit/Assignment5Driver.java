// Emanuel Langit
// emanuel.langit@my.ohecampus.com
// CKIT-510
// Assignment5Driver.java
// Driver class for assignment 5
// Week 5 Assignment
// August 7, 2013

import javax.swing.JFrame;

public class Assignment5Driver {
	public static void main(String[] args) {
		Assignment5App myApp = new Assignment5App();
		myApp.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		myApp.setLocationRelativeTo(null);
		myApp.setSize(525, 400);
		myApp.setVisible(true);
	}

}
